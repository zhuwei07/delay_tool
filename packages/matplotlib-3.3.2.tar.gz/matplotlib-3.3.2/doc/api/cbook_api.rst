********************
``matplotlib.cbook``
********************

.. automodule:: matplotlib.cbook
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: matplotlib.cbook.deprecation
   :members:
   :undoc-members:
   :show-inheritance:
