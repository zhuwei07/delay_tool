
:mod:`matplotlib.backends.backend_pgf`
======================================

.. automodule:: matplotlib.backends.backend_pgf
   :members:
   :undoc-members:
   :show-inheritance:
